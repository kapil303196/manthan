module.exports = {
  search: require('./search')
};
